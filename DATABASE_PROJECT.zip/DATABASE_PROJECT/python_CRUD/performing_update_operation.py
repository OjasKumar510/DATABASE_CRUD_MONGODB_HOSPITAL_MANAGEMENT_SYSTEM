from pymongo import MongoClient
#from . import medical_cases
import certifi
#from .medical_case import names,department_names,medical_cases
import random
#connecting with cluster of mongoDB atlas
client = MongoClient("mongodb+srv://akhricha05_db_user:PYDYSA6TMxTQhuXd@cluster0.fuu6229.mongodb.net/?appName=Cluster0",tlsCAFile=certifi.where())

#creating hospital database

hp_db=client["hospital"]

# creating collections for doc,patient,appoiments and departments

patient_collect=hp_db["patient_collect"]
doc_collect=hp_db["doctor_collect"]
appointment_collect=hp_db["appointment_collect"]
dept_collect=hp_db["dept_collect"]
#--------------updating the dates in all the collection-----------------
def extract_day_month_year(date):
    print("initial date:",date)
    day=""
    month=""
    year=""
    final_day=""
    final_month=""
    count=0
    for i in date:
        if(i!='-'):
            if(count==0):
                day+=i
            elif(count==1):
                month+=i
            else:
                year+=i
        else:
            count+=1
    print("initial day: ",day)
    print("initial month: ",month)
    print("initial year: ",year)
    if(len(day)<2):
        final_day+="0"
    if(len(month)<2):
        final_month+="0"
    final_day+=day
    final_month+=month
    final_date=final_day+"-"+final_month+"-"+year
    return final_date
def update_date(collect_name,num,field_name_id,field_name_date):
    count=1
    print("collection under update: ",collect_name)
    print("max number of records to be updated: ",num)
    print("field being updated: ",field_name_date)
    while(count<=num):
        print(field_name_id," : ",count)
        query={field_name_id:{"$eq":count}}
        data=collect_name.find_one(query)
        date_val=data[field_name_date]
        date_val_final=extract_day_month_year(date_val)
        update_query={"$set":{field_name_date:date_val_final}}
        cond_query={field_name_id:{"$eq":count}}
        collect_name.update_one(cond_query,update_query)
        print("final_date: ",date_val_final)
        count=count+1
update_date(doc_collect,50,"doc_id","date of joining")
update_date(patient_collect,50,"patient_id","dob")
update_date(appointment_collect,50,"apt_id","date")
#-----------------END OF FILE--------------------
