from pymongo import MongoClient
#from . import medical_cases
import certifi
#from .medical_case import names,department_names,medical_cases
import random
#connecting with cluster of mongoDB atlas
client = MongoClient("mongodb+srv://akhricha05_db_user:PYDYSA6TMxTQhuXd@cluster0.fuu6229.mongodb.net/?appName=Cluster0",tlsCAFile=certifi.where())

#creating hospital database

hp_db=client["hospital"]

# creating collections for doc,patient,appoiments and departments

patient_collect=hp_db["patient_collect"]
doc_collect=hp_db["doctor_collect"]
appointment_collect=hp_db["appointment_collect"]
dept_collect=hp_db["dept_collect"]

def display(_id):
    data=patient_collect.find({'patient_id':{"$eq":_id}})
    apts_data=appointment_collect.find({"pats_id":{"$eq":_id}})
    doc_id=apts_data[0]['doc_id']
    doc_data=doc_collect.find({"doc_id":{"$eq":doc_id}})
    val=data[0]
    print(val['patient_id'],val['name'],val['dob'],val['Age'],val['symptoms'])
    val_doc=doc_data[0]
    print(val_doc['doc_id'],val_doc['name'],val_doc['date of joining'],val_doc['dept_id'])
    apts_val=apts_data[0]
    print(apts_val['apt_id'],apts_val['doc_id'],apts_val['pats_id'],apts_val['time'],apts_val['date'],apts_val['diagnosis'],apts_val['symptoms'])
    #apt_field=["apt_id","doc_id","pats_id","time","date","diagnosis","symptoms"]
    #doc_fields=["doc_id","name","date of joining","dept_id"]
    #patient_field=["patient_id","name","dob","Age","symptoms"]
display(1)
#-------------***************-------------inserting data--------------------***************---------------------
# function for generating the dates
def calc_date(count3,count2,count1,stat):
    stat=stat%3
    if(stat==0):
        count1+=1
    elif (stat==1):
        if(count2<12):
            count2+=1
        else:
            count2=1
            if(count3<28):
                count3+=1
            else:
                count3=1
                count1+=1
    else:
        if(count3<28):
            count3+=1
        else:
            count3=1
            if(count2<12):
                count2+=1
            else:
                count2=1
                count1+=1
    stat+=1
    dates=str(count3)+"-"+str(count2)+"-"+str(count1)
    return [count3,count2,count1,stat,dates]

#function for generating time 

def calc_time(hrs,mins):
    if(hrs>19):
        hrs=14
    if(mins==60):
        mins=0
    hrs+=1
    mins+=5
    minss=""
    if(mins<10):
        minss+="0"
    minss+=str(mins)
    final_time=str(hrs)+":"+minss
    return [hrs,mins,final_time]


#-----------------inserting department data-------------------

dept_data=[]

list_fields=["dept_id","dept_name"]

count=1

#dictionary to map dept_id to dept_name

dept_id_dept_name={}

for i in department_names:
    dics={}
    dept_id_dept_name.update({i:count})
    dics.update({list_fields[0]:count})
    dics.update({list_fields[1]:i})
    dept_data.append(dics)
    count+=1

dept_collect.insert_many(dept_data)

#-------------------- department data inserted successfully -----------------

#collecting names for patient and doctor 



count=0
doc_names=[]
patient_names=[]
for i in names :
    if(count<50):
        doc_names.append(i)
    else:
        patient_names.append(i)
    count+=1


#-------------------inserting doctor data-------------------

doc_fields=["doc_id","name","date of joining","dept_id"]


count1=1996 
count2=11
count3=1
stat=0
count=0
doc_ids=1
count_val=0


doc_data=[]


while(count<50):
    dics={}
    dics.update({doc_fields[0]:doc_ids})
    doc_ids+=1
    dics.update({doc_fields[1]:doc_names[count]})
    list_val=calc_date(count3,count2,count1,stat)
    count3=list_val[0]
    count2=list_val[1]
    count1=list_val[2]
    stat=list_val[3]
    dics.update({doc_fields[2]:list_val[4]})
    vals=int(count/13)
    dics.update({doc_fields[3]:(vals+1)})
    doc_data.append(dics)
    count+=1


doc_collect.insert_many(doc_data)


#---------------------doctor data inserted successfully-----------------------

#------------------inserting patient data-------------------------------------



patient_field=["patient_id","name","dob","Age","symptoms"]

patient_data=[]
count=0
count1=1979
count2=1
count3=1
stat=0
while(count<50):
    dics={}
    symptoms=medical_cases[count]["symptoms"]
    list_val=calc_date(count3,count2,count1,stat)
    count3=list_val[0]
    count2=list_val[1]
    count1=list_val[2]
    stat=list_val[3]
    dob=list_val[4]
    Age=2026-count3
    name=patient_names[count]
    patient_id=count+1
    count+=1
    patient_datas=[patient_id,name,dob,Age,symptoms]
    for i in range(len(patient_datas)):
        dics.update({patient_field[i]:patient_datas[i]})
    patient_data.append(dics)

patient_collect.insert_many(patient_data)

#--------------------patient data inserted successfully -------------------------

#---------------------inserting appointment datas---------------------

count=0

apt_field=["apt_id","doc_id","pats_id","time","date","diagnosis","symptoms"]

dataset_appoint=[]

hrs=14
mins=0
count1=2003
count2=1
count3=1
stat=0
count=0
count_docs_assign=0


#creating appointment data

while(count<50):
    list_data=[]
    apt_id=count+1
    pats_id=count+1

    #collecting the symptoms through select operation on the patient collection

    query={"patient_id":{"$eq":pats_id}}
    pat_data=patient_collect.find_one(query)

    symptoms=pat_data["symptoms"]

    #finding the diagnosis and department_name

    diagnosis=""
    dept_name=""
    for i in medical_cases:
        if i["symptoms"]==symptoms:
            diagnosis+=i["diagnosis"]
            dept_name+=i["department_name"]
            break
    
    #finding the docs_id

    dept_id=dept_id_dept_name[dept_name]
    print("dept_id:",dept_id)
    query={"dept_id":{"$eq":dept_id}}
    list_docs_assign=doc_collect.find(query)
    res=list(list_docs_assign)
    val=random.randint(0,len(res)-1)

    doc_id=res[val]["doc_id"]

    #generating time and date

    list_time=calc_time(hrs,mins)
    hrs=list_time[0]
    mins=list_time[1]

    final_time=list_time[2]

    list_date=calc_date(count3,count2,count1,stat)

    count3=list_date[0]
    count2=list_date[1]
    count1=list_date[2]
    stat=list_date[3]

    final_date=list_date[4]

    count+=1

    #adding into the final dataset 

    list_data=[apt_id,doc_id,pats_id,final_time,final_date,diagnosis,symptoms]
    
    dics_data={}

    for i in range(len(list_data)):
        dics_data.update({apt_field[i]:list_data[i]})
    dataset_appoint.append(dics_data)
    
appointment_collect.insert_many(dataset_appoint)
#---------------appointment data inserted successfully------------------