from pymongo import MongoClient
#from . import medical_cases
import certifi
#from .medical_case import names,department_names,medical_cases
import random
#connecting with cluster of mongoDB atlas
client = MongoClient("mongodb+srv://akhricha05_db_user:PYDYSA6TMxTQhuXd@cluster0.fuu6229.mongodb.net/?appName=Cluster0",tlsCAFile=certifi.where())

#creating hospital database

hp_db=client["hospital"]

# creating collections for doc,patient,appoiments and departments

patient_collect=hp_db["patient_collect"]
doc_collect=hp_db["doctor_collect"]
appointment_collect=hp_db["appointment_collect"]
dept_collect=hp_db["dept_collect"]

#-----performing read operations--------
def read_data(collect_name,condition_field,condition_operator,value,field_list,collection_name):
    print("initiated querying data from collection : ",collection_name)
    query={condition_field:{condition_operator:value}}
    data_list=collect_name.find(query)
    print("---------end of querying------------")
    print("printing the records")
    count=0
    for data in data_list:
        print("printing the record no.: ",count)
        count=count+1
        for i in field_list:
            print(i,":",data[i])
    print("-----------------end of reading data--------------")



doc_fields=["doc_id","name","date of joining","dept_id"]

#------displaying doctors of cardiology department-------------
read_data(doc_collect,"dept_id","$eq",3,doc_fields,"doctor_collect")



patient_field=["patient_id","name","dob","Age","symptoms"]

#-------------displaying patients of age 43 or below---------------
read_data(patient_collect,"Age","$lte",43,patient_field,"patient_collect")
