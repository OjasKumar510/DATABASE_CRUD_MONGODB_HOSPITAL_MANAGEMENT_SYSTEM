names = [
    "Liam", "Olivia", "Noah", "Emma", "Oliver", "Charlotte", "James", "Amelia",
    "Elijah", "Sophia", "William", "Isabella", "Henry", "Ava", "Lucas", "Mia",
    "Benjamin", "Evelyn", "Theodore", "Harper", "Mateo", "Luna", "Levi", "Camila",
    "Sebastian", "Gianna", "Daniel", "Elizabeth", "Jack", "Eleanor", "Alexander", "Ella",
    "Owen", "Abigail", "Ethan", "Sophia", "Asher", "Avery", "Samuel", "Scarlett",
    "Ethan", "Emily", "Leo", "Aria", "Jackson", "Penelope", "Mason", "Chloe",
    "Ezra", "Layla", "John", "Mila", "Hudson", "Nora", "Luca", "Hazel",
    "Aiden", "Madison", "David", "Ellie", "Joseph", "Lily", "Wyatt", "Nova",
    "Matthew", "Isla", "Luke", "Grace", "Julian", "Violet", "Grayson", "Aurora",
    "Isaac", "Riley", "Jayden", "Zoey", "Theodore", "Willow", "Gabriel", "Emelia",
    "Anthony", "Stella", "Dylan", "Maya", "Leo", "Victoria", "Lincoln", "Hannah",
    "Jaxon", "Addison", "Maverick", "Leah", "Josiah", "Lucy", "Christopher", "Eliana",
    "Andrew", "Ivy", "Caleb", "Everly"
]
department_names=["Dermatology","Neurology","cardiology","general_physician"]
medical_cases = [
    {
        "symptoms": "Itchy, red, scaly patches on elbows and knees",
        "diagnosis": "Psoriasis",
        "department_name": "Dermatology"
    },
    {
        "symptoms": "Red facial flush, visible blood vessels, and pimple-like bumps",
        "diagnosis": "Rosacea",
        "department_name": "Dermatology"
    },
    {
        "symptoms": "Dry, intensely itchy skin with red inflammation in skin folds",
        "diagnosis": "Atopic Dermatitis (Eczema)",
        "department_name": "Dermatology"
    },
    {
        "symptoms": "Painful, fluid-filled blister rash following a single nerve stripe on one side of the body",
        "diagnosis": "Herpes Zoster (Shingles)",
        "department_name": "Dermatology"
    },
    {
        "symptoms": "Circular ring-shaped rash with raised edges and clearer skin in the center",
        "diagnosis": "Tinea Corporis (Ringworm)",
        "department_name": "Dermatology"
    },
    {
        "symptoms": "Asymmetrical dark mole with irregular borders and color variation",
        "diagnosis": "Melanoma",
        "department_name": "Dermatology"
    },
    {
        "symptoms": "Comedones, papules, pustules, and nodular lesions on face and back",
        "diagnosis": "Acne Vulgaris",
        "department_name": "Dermatology"
    },
    {
        "symptoms": "Itchy raised welts that appear suddenly after allergen exposure",
        "diagnosis": "Urticaria (Hives)",
        "department_name": "Dermatology"
    },
    {
        "symptoms": "Patchy loss of skin pigment resulting in smooth white skin areas",
        "diagnosis": "Vitiligo",
        "department_name": "Dermatology"
    },
    {
        "symptoms": "Thickened, yellowish, brittle, and crumbling fingernails",
        "diagnosis": "Onychomycosis",
        "department_name": "Dermatology"
    },
    {
        "symptoms": "Excessive hair shedding causing noticeable diffuse hair thinning",
        "diagnosis": "Telogen Effluvium",
        "department_name": "Dermatology"
    },
    {
        "symptoms": "Honey-colored crusted sores around the mouth and nose",
        "diagnosis": "Impetigo",
        "department_name": "Dermatology"
    },
    {
        "symptoms": "Coin-shaped itchy, crusted, and scaling skin lesions",
        "diagnosis": "Nummular Eczema",
        "department_name": "Dermatology"
    },

    # --- Neurology ---
    {
        "symptoms": "Throbbing headache on one side of the head, light sensitivity, and nausea",
        "diagnosis": "Migraine",
        "department_name": "Neurology"
    },
    {
        "symptoms": "Resting tremors in hands, muscle stiffness, and slow voluntary movement",
        "diagnosis": "Parkinson's Disease",
        "department_name": "Neurology"
    },
    {
        "symptoms": "Sudden numbness or weakness on one side of body, slurred speech, and facial drooping",
        "diagnosis": "Ischemic Stroke",
        "department_name": "Neurology"
    },
    {
        "symptoms": "Numbness, tingling, and sharp pain in the thumb, index, and middle fingers",
        "diagnosis": "Carpal Tunnel Syndrome",
        "department_name": "Neurology"
    },
    {
        "symptoms": "Recurrent unprovoked seizures with loss of consciousness and muscle jerking",
        "diagnosis": "Epilepsy",
        "department_name": "Neurology"
    },
    {
        "symptoms": "Sudden inability to move muscles on one side of the face with drooping eye and mouth",
        "diagnosis": "Bell's Palsy",
        "department_name": "Neurology"
    },
    {
        "symptoms": "Spinning sensation (vertigo), loss of balance, and involuntary eye movements",
        "diagnosis": "Benign Paroxysmal Positional Vertigo (BPPV)",
        "department_name": "Neurology"
    },
    {
        "symptoms": "Sharp, shock-like electrical pain radiating down the back of the leg",
        "diagnosis": "Sciatica",
        "department_name": "Neurology"
    },
    {
        "symptoms": "Progressive muscle weakness, vision disturbances, fatigue, and balance issues",
        "diagnosis": "Multiple Sclerosis",
        "department_name": "Neurology"
    },
    {
        "symptoms": "Severe stabbing electric-shock-like pain across the cheek and jaw area",
        "diagnosis": "Trigeminal Neuralgia",
        "department_name": "Neurology"
    },
    {
        "symptoms": "Progressive short-term memory loss, confusion, and cognitive decline",
        "diagnosis": "Alzheimer's Disease",
        "department_name": "Neurology"
    },
    {
        "symptoms": "Burning pain, numbness, and hypersensitivity in feet and toes",
        "diagnosis": "Peripheral Neuropathy",
        "department_name": "Neurology"
    },
    {
        "symptoms": "Brief episodes of neurological deficit resolving completely within 24 hours",
        "diagnosis": "Transient Ischemic Attack (TIA)",
        "department_name": "Neurology"
    },

    # --- Cardiology ---
    {
        "symptoms": "Crushing chest pain radiating to left arm and jaw, sweating, and shortness of breath",
        "diagnosis": "Myocardial Infarction (Heart Attack)",
        "department_name": "cardiology"
    },
    {
        "symptoms": "Shortness of breath while lying flat, swollen ankles, and persistent fatigue",
        "diagnosis": "Congestive Heart Failure",
        "department_name": "cardiology"
    },
    {
        "symptoms": "Rapid fluttering heartbeat, palpitations, fatigue, and lightheadedness",
        "diagnosis": "Atrial Fibrillation",
        "department_name": "cardiology"
    },
    {
        "symptoms": "Chest pressure or discomfort during physical exertion that subsides with rest",
        "diagnosis": "Stable Angina Pectoris",
        "department_name": "cardiology"
    },
    {
        "symptoms": "Persistent high blood pressure readings without immediate physical symptoms",
        "diagnosis": "Essential Hypertension",
        "department_name": "cardiology"
    },
    {
        "symptoms": "Leg pain and cramping while walking that goes away after resting",
        "diagnosis": "Peripheral Artery Disease",
        "department_name": "cardiology"
    },
    {
        "symptoms": "Sharp chest pain that worsens with deep breathing and improves when sitting forward",
        "diagnosis": "Pericarditis",
        "department_name": "cardiology"
    },
    {
        "symptoms": "Slow heart rate, dizziness, fatigue, and near-fainting episodes",
        "diagnosis": "Bradycardia / Sick Sinus Syndrome",
        "department_name": "cardiology"
    },
    {
        "symptoms": "Fainting or chest tightness during exercise due to narrowed aortic heart valve",
        "diagnosis": "Aortic Stenosis",
        "department_name": "cardiology"
    },
    {
        "symptoms": "Pain, swelling, redness, and warmth in a single lower leg calf muscle",
        "diagnosis": "Deep Vein Thrombosis (DVT)",
        "department_name": "cardiology"
    },
    {
        "symptoms": "Unexplained shortness of breath, rapid heart rate, and chest pain upon inhalation",
        "diagnosis": "Pulmonary Embolism",
        "department_name": "cardiology"
    },
    {
        "symptoms": "Shortness of breath, chest pressure, and heart murmur due to thickened heart muscle wall",
        "diagnosis": "Hypertrophic Cardiomyopathy",
        "department_name": "cardiology"
    },

    # --- General Physician ---
    {
        "symptoms": "Fever, chills, body aches, dry cough, and fatigue",
        "diagnosis": "Influenza (Flu)",
        "department_name": "general_physician"
    },
    {
        "symptoms": "Burning sensation during urination, frequent urge to urinate, and cloudy urine",
        "diagnosis": "Urinary Tract Infection (UTI)",
        "department_name": "general_physician"
    },
    {
        "symptoms": "Productive cough with yellow-green phlegm, high fever, and chest tightness",
        "diagnosis": "Community-Acquired Pneumonia",
        "department_name": "general_physician"
    },
    {
        "symptoms": "Burning pain in upper abdomen after eating, acid regurgitation, and heartburn",
        "diagnosis": "Gastroesophageal Reflux Disease (GERD)",
        "department_name": "general_physician"
    },
    {
        "symptoms": "Fatigue, pale skin, cold hands and feet, and brittle nails",
        "diagnosis": "Iron Deficiency Anemia",
        "department_name": "general_physician"
    },
    {
        "symptoms": "Weight loss, excessive thirst, frequent urination, and blurred vision",
        "diagnosis": "Type 2 Diabetes Mellitus",
        "department_name": "general_physician"
    },
    {
        "symptoms": "Fatigue, weight gain, constipation, dry skin, and cold intolerance",
        "diagnosis": "Hypothyroidism",
        "department_name": "general_physician"
    },
    {
        "symptoms": "Sore throat, difficulty swallowing, swollen tonsils with white spots, and fever",
        "diagnosis": "Streptococcal Pharyngitis (Strep Throat)",
        "department_name": "general_physician"
    },
    {
        "symptoms": "Right lower quadrant abdominal pain, nausea, vomiting, and low-grade fever",
        "diagnosis": "Acute Appendicitis",
        "department_name": "general_physician"
    },
    {
        "symptoms": "Watery diarrhea, abdominal cramps, nausea, and low-grade fever",
        "diagnosis": "Acute Gastroenteritis",
        "department_name": "general_physician"
    },
    {
        "symptoms": "Sneeze, runny nose, nasal congestion, and mild sore throat without high fever",
        "diagnosis": "Acute Nasopharyngitis (Common Cold)",
        "department_name": "general_physician"
    },
    {
        "symptoms": "High fever, joint pain, muscle pain, and retro-orbital headache after mosquito bite",
        "diagnosis": "Dengue Fever",
        "department_name": "general_physician"
    },
    {
        "symptoms": "Severe pain in sudden attacks, swelling, and redness in the big toe joint",
        "diagnosis": "Gouty Arthritis",
        "department_name": "general_physician"
    }
]