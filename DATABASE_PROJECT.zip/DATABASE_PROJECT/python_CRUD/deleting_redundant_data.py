from pymongo import MongoClient
#from . import medical_cases
import certifi
#from .medical_case import names,department_names,medical_cases
import random
#connecting with cluster of mongoDB atlas
client = MongoClient("mongodb+srv://akhricha05_db_user:PYDYSA6TMxTQhuXd@cluster0.fuu6229.mongodb.net/?appName=Cluster0",tlsCAFile=certifi.where())

#creating hospital database

hp_db=client["hospital"]

# creating collections for doc,patient,appoiments and departments

patient_collect=hp_db["patient_collect"]
doc_collect=hp_db["doctor_collect"]
appointment_collect=hp_db["appointment_collect"]
dept_collect=hp_db["dept_collect"]

#------- deleting patient,doctor data------------------

count=0
def del_data(id,collect_name,field_name):
    query={field_name:{"$eq":id}}
    list_red_data=collect_name.find(query)
    final_list=list(list_red_data)
    if(len(final_list)>1):
        data_store=final_list[0]
        collect_name.delete_many(query)
        collect_name.insert_one(data_store)
        print(id,collect_name,field_name)
while(count<50):
    del_data(count+1,patient_collect,"patient_id")
    del_data(count+1,doc_collect,"doc_id")
    del_data(count+1,appointment_collect,"apt_id")
    if(count<4):
        del_data(count+1,dept_collect,"dept_id")
    count=count+1
