import python_CRUD 
from python_CRUD import deleting_redundant_data